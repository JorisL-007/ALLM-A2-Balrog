"""BALROG entry point; research implementations live in exercises/."""

import sys
from pathlib import Path

# Also support invoking BALROG/eval.py directly from its own checkout.
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from exercises.common.agent_registry import create_research_agent


def CustomAgent(client_factory, prompt_builder):
    return create_research_agent(client_factory, prompt_builder)
