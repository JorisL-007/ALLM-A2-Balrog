"""Verification only: saved replies through real BALROG environments, no inference."""
import csv,json,os,sys,time,copy
from pathlib import Path
from types import SimpleNamespace
ROOT=Path.cwd();sys.path[:0]=[str(ROOT),str(ROOT/'BALROG')]
from omegaconf import OmegaConf
from openai.types.chat import ChatCompletion
from openai import RateLimitError
import httpx
import balrog.client as client_module
from balrog.agents import AgentFactory
from balrog.evaluator import Evaluator
from exercises.common.profiles import transfer_case
from exercises.common.run_experiments import episode_command,verify_case,completed_case,check_manifest
from exercises.common.transport_audit import read_attempts,spending

output=Path('/tmp/balrog_transfer_transport_replay');output.mkdir(exist_ok=True)
base=ROOT/'experiment_results/followup_v1/episodes/babyai'
reflection_source=next(p for p in sorted((base/'goto/e3').rglob('llm_calls.jsonl')) if '"role": "reflection"' in p.read_text())
examples=[('naive',base/'goto/naive/seed_030/rep_0/llm_calls.jsonl'),
          ('plan',base/'pickup/plan/seed_030/rep_0/llm_calls.jsonl'),('e3',reflection_source)]
results=[]
for condition,source in examples+[('cot',None)]:
    if source:
        data=[json.loads(line) for line in source.read_text().splitlines()]
        original=json.loads((source.parent/'complete.json').read_text());task=original['task'];seed=original['seed'];budget=original['budget']
    else:
        raw=min((row['Reasoning'] for path in (ROOT/'exercise1_results/20261014_221758/qwen4-instruct/cot/run_1/babyai').rglob('*.csv') for row in csv.DictReader(path.open()) if 'ACTION:' in row['Reasoning']),key=len)
        # Only parsing/accounting is checked here; this is not an episode from the original study.
        data=[dict(raw_response=raw,input_tokens=100,output_tokens=80)]*4
        task,seed,budget='goto',20,4
    c=transfer_case('qwen4-instruct','babyai',task,seed,condition,budget,pilot=True)
    work=output/condition;work.mkdir(exist_ok=True)
    for name in ['llm_calls.jsonl','api_attempts.jsonl']:
        if (work/name).exists():(work/name).unlink()
    command,flags=episode_command(c,work,8091);os.environ.update(flags)
    cfg=OmegaConf.merge(OmegaConf.load(ROOT/'BALROG/balrog/config/config.yaml'),OmegaConf.from_dotlist(command[command.index('eval.py')+1:]+['client.delay=0']))
    captures=[];position=[0];attempted=[False]
    class RecordedOpenAI:
        def __init__(self,**kwargs):
            assert kwargs['max_retries']==0 and kwargs['timeout']==60
            self.chat=SimpleNamespace(completions=self)
        def create(self,**kwargs):
            if not attempted[0]:
                attempted[0]=True
                raise RateLimitError('simulated retry; no network request',response=httpx.Response(429,request=httpx.Request('POST','https://verification.invalid')),body={})
            record=data[position[0]];position[0]+=1
            messages=[dict(role=m['role'],content=m['content'][0]['text']) for m in kwargs['messages']]
            if source:assert messages==record['messages'],(condition,position[0],'prompt changed')
            captures.append(messages)
            return ChatCompletion(id=f'verification-{position[0]}',created=0,model=kwargs['model'],object='chat.completion',
                choices=[dict(index=0,finish_reason='stop',message=dict(role='assistant',content=record['raw_response']))],
                usage=dict(prompt_tokens=record['input_tokens'],completion_tokens=record['output_tokens'],total_tokens=record['input_tokens']+record['output_tokens']))
    client_module.OpenAI=RecordedOpenAI
    begin=time.monotonic()
    result=Evaluator('babyai',cfg,original_cwd=str(ROOT/'BALROG'),output_dir=str(work)).run_episode('BabyAI-MixedTrainLocal-v0/'+task,AgentFactory(cfg).create_agent())
    if source:assert position[0]==len(data)
    meta={k:c[k] for k in ['panel','environment','task','seed','condition','budget','repeat','model_label','model','backend','context','tokens','history','pilot']}
    meta.update(elapsed_seconds=time.monotonic()-begin,verification_only=True,**{k:result[k] for k in ['progression','num_steps','input_tokens','output_tokens']})
    (work/'complete.json').write_text(json.dumps(meta))
    assert verify_case(work,c) is not None and completed_case(work,c)
    attempts=read_attempts(work/'api_attempts.jsonl');assert len(attempts)==len(data)+1 and attempts[0]['event']=='error'
    changed={**c,'tokens':128};assert not completed_case(work,changed)
    results.append(dict(condition=condition,steps=result['num_steps'],recorded_responses=len(data),transport_attempts=len(attempts),reflection_calls=sum(d.get('role')=='reflection' for d in data),source=str(source),unchanged_saved_prompts=bool(source),transport_and_resume_verification='passed',synthetic_usage=condition=='cot'))
# Pin/reject the manifest independently of any model, retaining the same completed evidence.
p=output/'manifest_check';check_manifest(p,[c]);check_manifest(p,[c])
try:check_manifest(p,[{**c,'tokens':128}]);raise AssertionError('changed settings accepted')
except SystemExit:pass
manifest=json.loads((p/'manifest.json').read_text());original=copy.deepcopy(manifest);manifest['source_hashes']['verification_change']='wrong';(p/'manifest.json').write_text(json.dumps(manifest))
try:check_manifest(p,[c]);raise AssertionError('changed hash accepted')
except SystemExit:pass
(p/'manifest.json').write_text(json.dumps(original))
(output/'verification.json').write_text(json.dumps(dict(verification_only=True,inference_calls=0,results=results),indent=2)+'\n')
print(json.dumps(results,indent=2))
