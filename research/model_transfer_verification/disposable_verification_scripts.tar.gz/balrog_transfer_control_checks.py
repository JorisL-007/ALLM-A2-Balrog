"""Disposable control-flow checks. No network or model execution."""
import copy,hashlib,json,os,sys,shutil
from pathlib import Path
from types import SimpleNamespace
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
import exercises.common.model_transfer as study
import exercises.common.run_experiments as runner
from exercises.common.profiles import transfer_case
from exercises.common.transport_audit import spending
root=Path('/tmp/balrog_transfer_flow_checks');root.mkdir(exist_ok=True)
# A verified completed episode is skipped without rewriting it or starting any process.
base=Path('/tmp/balrog_transfer_transport_replay/plan');meta=json.loads((base/'complete.json').read_text())
c=transfer_case('qwen4-instruct','babyai',meta['task'],meta['seed'],'plan',meta['budget'],pilot=True)
out=root/'resume';target=runner.target_directory(out,c);target.parent.mkdir(parents=True,exist_ok=True)
if not target.exists():shutil.copytree(base,target)
def hashes(folder):return {str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}
before=hashes(target);assert runner.run_case(out,c,8097)==('skip',0);assert hashes(target)==before
# A retained interrupted attempt survives retry; the simulated failed child never calls a model.
failed_out=root/'interrupted';work=runner.target_directory(failed_out,c);work=work.with_name(work.name+'.working');work.mkdir(parents=True,exist_ok=True);(work/'interrupted_marker').write_text('retain me')
original=runner.subprocess.Popen
class FailedChild:
 returncode=1
 def __init__(self,*args,**kwargs):pass
 def wait(self,timeout=None):return 1
runner.subprocess.Popen=FailedChild
try:
 try:runner.run_case(failed_out,c,8097);raise AssertionError('failed child accepted')
 except RuntimeError:pass
finally:runner.subprocess.Popen=original
assert list(work.parent.glob('*.incomplete_*/interrupted_marker'))
assert (work/'failure.json').exists()
# Exercise the real stage loop at both sides of the requested cloud spending thresholds.
# The episode callback is a recorder; it performs zero inference and writes no results.
originals={name:getattr(study,name) for name in ['transfer_cases','transfer_pilots','run_case','analyze','pin_server']}
seen=[]
study.transfer_cases=lambda:[transfer_case(label,'babyai','goto',30,'naive',32) for label in ['gpt41mini-cloud','olmo1b-local']]
study.transfer_pilots=lambda label:[]
study.analyze=lambda out:None
study.pin_server=lambda *args:(None,{})
study.run_case=lambda out,c,port:(seen.append(c['model_label']) or ('done',0))
os.environ['OPENAI_API_KEY']='verification-only-no-request-is-issued'
for amount in [10.01,20.01]:
 path=root/str(amount);path.mkdir(exist_ok=True)
 # check_manifest must see an empty directory first; the spending helper is patched
 # only to seed this invocation's ledger immediately after manifest creation.
 ledger=path/'api_attempts.jsonl'
 if not ledger.exists():
  original_check=study.check_manifest
  def check_manifest(out,cases):
   original_check(out,cases)
   ledger.write_text(json.dumps(dict(event='start',request_id='verification',uncertain_cost_usd=0))+'\n'+json.dumps(dict(event='response',request_id='verification',usage_available=True,cost_usd=amount))+'\n')
  study.check_manifest=check_manifest
 seen.clear()
 args=SimpleNamespace(model=None,condition=None,out=path,dry_run=False,hours=48,limit=0,port=8097,cloud_target_usd=10,cloud_stop_usd=20)
 study.run_study(args)
 if amount<20:assert seen==['gpt41mini-cloud','olmo1b-local'],seen
 else:
  assert seen==['olmo1b-local'],seen
  assert json.loads((path/'stage_status.json').read_text())['gpt41mini-cloud']['state']=='cloud spending limit'
 assert spending(path)['estimated_usd']==amount # persisted and read back without reset
 study.check_manifest=original_check
for key,value in originals.items():setattr(study,key,value)
(root/'checks.json').write_text(json.dumps(dict(verification_only=True,inference_calls=0,completed_skip_byte_identical=True,interrupted_attempt_retained=True,cloud_continues_above_10=True,cloud_stops_above_20_then_runs_olmo=True,cost_persisted=True),indent=2)+'\n')
print('PASS: resume, interrupted evidence, spending persistence and stage continuation; no model calls.')
